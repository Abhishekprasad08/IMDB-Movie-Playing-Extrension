chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

    const tabUrl = sender.tab ? sender.tab.url : 'URL not available';
    const regex = /\/title\/(tt\d+)\//;
    const match = (tabUrl).match(regex);
    id=match[1]
    console.log(id);
    sendResponse({ code: id });
  
});

  
// console.log('running');