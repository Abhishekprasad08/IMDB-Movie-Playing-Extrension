
let type=''

const watchnow = (id) => {
    // Hide existing media elements
    let element1 = document.querySelectorAll('[data-testid="hero-media__slate"]');
    element1.forEach(element => {
        element.style.display = "none";
    });

    // Check if the iframe with id 'a1b2c3' already exists
    let existingIframe = document.getElementById('a1b2c3');
    if (existingIframe) {
        // If it exists, just return and do nothing
        console.log('Iframe with id a1b2c3 already exists.');
        return;
    }

    // Create and style the new div
    let newDiv = document.createElement("div");
    newDiv.style.background = 'blue';
    newDiv.style.height = '100%';
    newDiv.style.width = '100%';
    newDiv.style.zIndex = '1';
    //abhishekprasad08

    // Append the new div to the designated element
    let element = document.getElementsByClassName("sc-491663c0-8 fLRGkU")[0];
    element.appendChild(newDiv);

    // Create and configure the new iframe
    let iframe = document.createElement("iframe");
    
    iframe.id = 'a1b2c3';
    iframe.width = "100%";
    iframe.height = "100%";

    if(type=='TV Series'){
      iframe.src = `https://vidsrc.xyz/embed/tv/${id}`;
      
    }else{
      iframe.src = `https://vidsrc.xyz/embed/movie/${id}`;
    }
    iframe.allowFullscreen = true;


    newDiv.appendChild(iframe);
    let video = document.getElementsByTagName('video')[0];
    if (video) {
       video.src=''
       
    }
}
const gettitleid=()=>{
  chrome.runtime.sendMessage({ msg:'get id'}, response => {
    watchnow(response.code)
  });
}



let buttonContainer = document.getElementsByClassName('sc-491663c0-11 hFWIYv')[0];

if (buttonContainer && buttonContainer.children.length >= 3) {
    let thirdChild = buttonContainer.children[2]; 

    let element = document.createElement('div');
    element.style.width = '100%';
    element.style.height = '50px';
    element.innerHTML ='watch now';
    element.style.backgroundColor = 'blue';
    element.style.color = 'white'; // Set text color for better contrast
    element.style.display = 'flex';
    element.style.justifyContent = 'center';
    element.style.marginTop = '5px';
    element.style.marginBottom = '5px';
    element.style.borderRadius = '7px';
    element.style.cursor = 'pointer';
    element.style.alignItems = 'center';
    element.addEventListener('click',gettitleid); // Corrected this line

    if (thirdChild.firstChild) {
        thirdChild.insertBefore(element, thirdChild.firstChild);
    } else {
        thirdChild.appendChild(element);
    }
}

let videotype=document.getElementsByClassName('sc-1f50b7c-0 iPPbjm')[0]

if (videotype && videotype.children.length >=2) {
    let thirdChild = videotype.children[1]; 
    let videotyp= thirdChild.children[0]
let videotypetext=videotyp.innerHTML
  type=videotypetext
}



document.getElementById('a1b2c3').addEventListener('load', function() {
  const iframeDocument = this.contentDocument || this.contentWindow.document;

  // Function to prevent redirection
  function preventRedirection(event) {
      event.preventDefault();
      event.stopPropagation();
      console.log('Redirection prevented');
  }

  // Adding event listener to capture all clicks within the iframe
  iframeDocument.addEventListener('click', preventRedirection, true);

  // Adding event listener for all forms to prevent their default submission
  const forms = iframeDocument.getElementsByTagName('form');
  for (let form of forms) {
      form.addEventListener('submit', preventRedirection, true);
  }

  // Modifying all links to remove the target attribute
  const links = iframeDocument.getElementsByTagName('a');
  for (let link of links) {
      link.removeAttribute('target');
      link.addEventListener('click', preventRedirection, true);
  }
});



document.getElementById('a1b2c3').onload = function() {
  var iframe = document.getElementById('a1b2c3');
  var iframeDocument = iframe.contentDocument || iframe.contentWindow.document;

  // Hide all image elements inside the iframe
  var images = iframeDocument.querySelectorAll('img');
  images.forEach(function(image) {
    image.style.display = 'none';
  });

  // Hide all elements with specific inner text
  var elements = iframeDocument.querySelectorAll('*');
  elements.forEach(function(element) {
    if (['VID', 'SRC', 'VIDSRC'].includes(element.innerText.trim())) {
      element.style.display = 'none';
    }
  });
};


